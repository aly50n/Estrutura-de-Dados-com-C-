#include <iostream>
//02- Faça um programa que leia dados informados pelo usuário e os armazene, um por um, no final de uma lista duplamente encadeada com descritor. O usuário para de informar valores quando digitar zero (que não deve ser inserido na lista). Considere que o tipo de dados da lista contém apenas um inteiro como informação. Faça um procedimento para dividir a lista ao meio, gerando duas novas listas. Caso haja um número ímpar de elementos, a primeira metade deve ficar com um elemento a mais. Imprima as listas resultantes.
using namespace std;

struct noLista{
  int dado;
  noLista *prox;
  noLista *ant;
};

struct descritor{
  noLista *ini;
  noLista *fim;
  int tam;
  descritor *prox;
};

descritor* inicializar(){
  descritor *d = new descritor;
  d->ini = NULL;
  d->fim = NULL;
  d->tam = 0;
  d->prox = NULL;
  return d;
}

void ins_no_fim(descritor *d, int dado){
  noLista* aux = new noLista;
  aux->ant= NULL;
  aux->prox= NULL;
  aux->dado = dado;
  if(d->ini == NULL){
    d->ini = aux;
    d->fim = aux;
    d->tam++;
  }
  else{
    aux->ant= d->fim;
    d->fim->prox= aux;
    d->fim = aux;
    d->tam++;
  }
}

bool dividir_lista(descritor* descritor){
  if(descritor->tam == 1 || descritor->tam == 0){
    return false;
  }
  else{
    int cont = 1, aux;
    noLista* lista = descritor->ini;
    descritor->prox = inicializar();
    if(descritor->tam%2 == 0){
        aux = descritor->tam/2;
        descritor->prox->tam = aux;
    }
    else{
        aux = (descritor->tam/2) + 1;
        descritor->prox->tam = aux-1;
    }
    while(cont < aux){
      lista = lista->prox;
      cont++;
    }
    descritor->prox->ini= lista->prox;
    descritor->prox->fim = descritor->fim;
    descritor->tam = aux;
    lista->prox= NULL;
    descritor->prox->ini->ant= NULL;
    descritor->fim = lista;
    return true;
  }
}

void imprimir_lista(descritor* d){
  noLista*l= d->ini;
  while(l != NULL){
    cout<<l->dado<<" ";
    l = l->prox;
  }
  cout<<endl;
}

int main() {
  descritor *d1;
  d1 = inicializar();
  int tam, pos,i, aux, info;
  cout<<"Digite o tamanho da sua lista: ";
  cin>>tam;
  //inserindo infos no inicio da primeira lista:
  for(i=0;i<tam;i++){
    cout<<"Digite as informações: ";
    cin>>info;
    ins_no_fim(d1,info);
  }
  cout<< "Lista completa: ";
  imprimir_lista(d1);
  cout<<"=========================\n";
  //teste para dividir as listas:
  if(dividir_lista(d1)){
    cout<< "\nA lista encadeada foi dividida em duas novas listas:\n";
    cout<< "Lista 1: ";
    imprimir_lista(d1);
    cout<< "Lista 2: ";
    imprimir_lista(d1->prox);
    
  }
  else{
    if(d1->tam == 0){
      cout<< "\nFalha na tentativa de dividir a lista!\nA lista não possui elementos!\n";
    }
    else{
      cout<< "\nFalha! A lista possui apenas um elemento e não pôde ser dividida!\n";
      cout<< "Único elemento da Lista: ";
      imprimir_lista(d1);
    }
  }
}