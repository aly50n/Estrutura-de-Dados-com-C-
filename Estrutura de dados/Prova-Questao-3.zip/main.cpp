#include <iostream>
using namespace std;
/* Questão 03 - Considere uma matriz de 5 linhas e 4 colunas contendo as seguintes informações sobre alunos de uma disciplina, sendo todas as informações do tipo double: 
• Primeira coluna: número de matrícula;
• Segunda coluna: média das provas;
• Terceira coluna: média dos trabalhos;
• Quarta coluna: nota final.
Elabore uma função que receba essa matriz e, considerando as três primeiras colunas como preenchidas, preencha a quarta coluna, sabendo que a nota final é a média ponderada de provas e trabalhos, com peso 7 para as provas e 3 para os trabalhos (3,0 pontos).
*/


void preencher_media_final(double matriz[5][4]){
  for(int j = 0;j<4;j++){
    for(int i = 0;i<5;i++){
      matriz[i][3] = ((matriz[i][1] *7) + (matriz[i][2]*3)) / (7+3);  
    } 
  }
}

int main() {
  double matriz[5][4];
  matriz[0][0] = 1;
  matriz[1][0] = 1;
  matriz[2][0] = 1;
  matriz[3][0] = 1;
  matriz[4][0] = 1;
  
  matriz[0][1] = 10;
  matriz[1][1] = 6;
  matriz[2][1] = 8;
  matriz[3][1] = 9;
  matriz[4][1] = 7;

  matriz[0][2] = 10;
  matriz[1][2] = 10;
  matriz[2][2] = 10;
  matriz[3][2] = 10;
  matriz[4][2] = 7;

  preencher_media_final(matriz);
  for(int i = 0;i<5;i++){
    for(int j = 1;j<4;j++){
      cout<<matriz[i][j]<<" ";
    }
    cout<<"\n";
  }
}