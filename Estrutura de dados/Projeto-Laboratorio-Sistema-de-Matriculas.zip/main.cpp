#include <iostream>

using namespace std;

struct aluno{
  string nome;
  int matricula;
  aluno *prox;
  aluno *ant;
};

struct turma{
  string nomeDaTurma;
  int serie, tamanho;
  aluno *ini, *fim;
  turma *prox;
  turma *ant;
};

turma* inicializar(){
  turma *t = new turma;
  t->nomeDaTurma= "";
  t->serie = 0;
  t->ini = NULL;
  t->fim = NULL;
  t->tamanho = 0;
  t->prox = NULL;
  t->ant = NULL;
  return t;
}

bool criar_turma(turma *&t, string nome_turma, int serie){
  turma *nova = inicializar(), *aux;
  nova->nomeDaTurma = nome_turma;
  nova->serie = serie;
  if(t->serie == 0){
    t = nova;
  }
  else{
    aux = t;
    if((to_string(nova->serie) + nova->nomeDaTurma) < (to_string(aux->serie) + aux->nomeDaTurma)){
      nova->prox = aux;
      aux->ant = nova;
      t = nova;
      return true;
    }
    while(aux->prox != NULL && (to_string(nova->serie) + nova->nomeDaTurma) > (to_string(aux->serie) + aux->nomeDaTurma)){
      aux = aux->prox;
    }
    if(aux->prox == NULL && (to_string(nova->serie) + nova->nomeDaTurma) > (to_string(aux->serie) + aux->nomeDaTurma)) {
      aux->prox = nova;
      nova->ant = aux;
      nova->prox = NULL;
    }
    else{
      aux->ant->prox= nova;
      nova->ant = aux->ant;
      nova->prox = aux;
      aux->ant = nova;
    }
  }
  return true;
}

void listar_turmas(turma *t){
  while(t != NULL){
    cout<< t->serie<<" "<< t->nomeDaTurma <<", ";
    t = t->prox;
  }
}

bool inserir_aluno_turma_desejada(turma *t, int serie, string turm){
  if(t->serie == 0){
    return false;
  }
  else{
    aluno *aux;
    turma *auxT;
    int cont = 0;
    aluno *novo = new aluno;
    cout<<"\nDigite a matricula do aluno: ";
    cin>>novo->matricula;
    setbuf(stdin, NULL);
    cout<<"Digite o nome do aluno: ";
    getline(cin,novo->nome);
    setbuf(stdin, NULL);
    novo->prox = NULL;
    novo->ant = NULL;
    while(t != NULL){
      if(t->serie == serie && t->nomeDaTurma == turm){
        aux = t->ini;
        auxT = t;
        cont++;
      }
      t = t->prox;
    }
    if(cont == 0){
      return false;
    }
    if(aux == NULL){
      auxT->ini = novo;
      auxT->fim = novo;
      auxT->tamanho++;
    }
    else{
      string auxN = aux->nome;
      while(aux->prox != NULL && novo->nome > aux->nome){
        aux = aux->prox;
      }
      if(aux->prox == NULL){
        if(novo->nome > aux->nome){
          aux->prox = novo;
          novo->ant = aux;
          auxT->fim = novo;
          auxT->tamanho++;
        }
        else if(novo->nome < aux->nome && auxT->tamanho == 1){
          novo->prox = aux;
          aux->ant = novo;
          auxT->ini = novo;
          auxT->tamanho++;
        }
        else{
          novo->ant = aux->ant;
          aux->ant->prox = novo;
          novo->prox = aux;
          aux->ant = novo;
          auxT->tamanho++;
        }
      }
      else if(aux->nome == auxN){
        novo->prox = aux;
        aux->ant = novo;
        auxT->ini = novo;
        auxT->tamanho++;
      }
      else{
        novo->ant = aux->ant;
        aux->ant->prox = novo;
        novo->prox = aux;
        aux->ant = novo;
        auxT->tamanho++;
      }
    }
  }
  return true;
}

bool inserir_aluno_menor_numero(turma *t, int serie){
  aluno *aux;
  turma *auxT = t;
  if(t->serie == 0){
    return false;
  }
  else{
    int auxTamanho= t->tamanho;
    int cont = 0;
    aluno *novo = new aluno;
    cout<<"\nDigite a matricula do aluno: ";
    cin>>novo->matricula;
    setbuf(stdin, NULL);
    cout<<"Digite o nome do aluno: ";
    getline(cin,novo->nome);
    setbuf(stdin, NULL);
    novo->prox = NULL;
    novo->ant = NULL;
    while(t != NULL){
      if(serie == t->serie && auxTamanho >= t->tamanho){
        aux = t->ini;
        auxT = t;
        auxTamanho = t->tamanho;
        cont++;
      }
      t = t->prox;
    }
    if(cont == 0){
      return false;
    }
    if(aux == NULL){
      auxT->ini = novo;
      auxT->fim = novo;
      auxT->tamanho++;
    }
    else{
      string auxN = aux->nome;
      while(aux->prox != NULL && novo->nome > aux->nome){
        aux = aux->prox;
      }
      if(aux->prox == NULL){
        if(novo->nome > aux->nome){
          aux->prox = novo;
          novo->ant = aux;
          auxT->fim = novo;
          auxT->tamanho++;
        }
        else if(novo->nome < aux->nome && auxT->tamanho == 1){
          novo->prox = aux;
          aux->ant = novo;
          auxT->ini = novo;
          auxT->tamanho++;
        }
        else{
          novo->ant = aux->ant;
          aux->ant->prox = novo;
          novo->prox = aux;
          aux->ant = novo;
          auxT->tamanho++;
        }
      }
      else if(aux->nome == auxN){
        novo->prox = aux;
        aux->ant = novo;
        auxT->ini = novo;
        auxT->tamanho++;
      }
      else{
        novo->ant = aux->ant;
        aux->ant->prox = novo;
        novo->prox = aux;
        aux->ant = novo;
        auxT->tamanho++;
      }
    }
  }
  cout<<"\nInserido na série: "<<auxT->serie<<" Turma: "<<auxT->nomeDaTurma<<"\n";
  return true;
}

void listar_alunos_turma_determinada(turma *t, string nomeTurma, int serie){
  aluno *aux;
  turma *auxT;
  int cont =0;
  while(t != NULL){
    if((to_string(serie) + nomeTurma) == (to_string(t->serie) + t->nomeDaTurma)){
      aux = t->ini;
      auxT= t;
    }
    t= t->prox;
  }
  cout<<"\n=======================";
  if(aux != NULL){
    cout<<"\nAlunos da Série: "<<serie<<" Turma: "<<nomeTurma<<", Quantidade de Alunos: "<<auxT->tamanho<<"\n";
    while(aux!=NULL){
      cont++;
      cout<<"\n"<<cont<<"-"<<aux->nome<<", Matricula: "<<aux->matricula;
      aux= aux->prox;
    }
  }
  if(cont == 0){
    cout<<"\nTurma vazia ou Inexistente.";
  }
  cout<<"\n=======================\n";
  
}

void relatorio_completo(turma *t){
  aluno *aux;
  int cont =0;
  while(t != NULL){
    cont = 0;
    cout<<"\n==================================";
    aux=t->ini;
    cout<<"\nAlunos da Série: "<<t->serie<<" Turma: "<<t->nomeDaTurma<<", Quantidade de Alunos: "<<t->tamanho<<"\n";
    if(t->tamanho == 0)
      cout<<"TURMA VAZIA!";
    while(aux != NULL){
      cont++;
      cout<<"\n"<<cont<<" - "<<aux->nome<<", Matricula: "<<aux->matricula;
      aux= aux->prox;
    }
    cout<<"\n==================================\n";
    t= t->prox;
  }
}

int main(){
  string nome_aluno, nome_turma;
  int serie, matricula;
  turma *turmas = inicializar();
  int menu = -1;
  while(menu !=0){
    setbuf(stdin, NULL);
    cout<<"\nEscolha uma opção:\n1 - Criar nova turma\n2 - Listar turmas\n3 - Inserir aluno em turma determinada\n4 - Inserir aluno na turma mais vaga\n5 - Listar alunos de turma determinada\n6 - Relatório completo\n0 - Sair.\n";
    cout<<"Digite: ";
    cin>>menu;

    if(menu == 1){
      cout<<"\nDigite a serie da nova turma: ";
      cin>>serie;
      setbuf(stdin, NULL);
      cout<<"Digite o nome da nova turma: ";
      getline(cin,nome_turma);
      setbuf(stdin, NULL);
      if(criar_turma(turmas,nome_turma,serie)){
        cout<<"\n==================================";
        cout<<"\nTurma: "<<nome_turma<<" da "<<serie<<"ª série criada!\n";
        cout<<"==================================\n";
      }
      else{
        cout<<"\n==================================";
        cout<<"\nErro ao criar a turma!\n";
        cout<<"\n==================================\n";
      }
    }
    else if(menu == 2){
      cout<<"\n==================================";
      cout<<"\nAs turmas existentes são: ";
      listar_turmas(turmas);
      cout<<"\n==================================";
    }
    else if(menu == 3){
      cout<<"\n==================================";
      cout<<"\nDigite a serie que deseja colocar o aluno: ";
      cin>>serie;
      setbuf(stdin, NULL);
      cout<<"Digite o nome da turma que deseja colocar o aluno: ";
      getline(cin,nome_turma);
      setbuf(stdin, NULL);
    
      if(inserir_aluno_turma_desejada(turmas, serie, nome_turma)){
        cout<<"\nAluno Inserido na turma solicitada!\n";
      }
      else{
        cout<<"\nTurma não encontrada!\n";
      }
      setbuf(stdin, NULL);
      cout<<"==================================";
    }
    else if(menu == 4){
      cout<<"\n==================================";
      cout<<"\nDigite a serie que o aluno deve estudar: ";
      cin>>serie;
      setbuf(stdin, NULL);
      if(!inserir_aluno_menor_numero(turmas,serie))
        cout<<"\nErro! Série não existe.\n";
      cout<<"==================================";
    }
    else if(menu == 5){
      cout<<"\nDigite a serie que deseja a lista dos alunos: ";
      cin>>serie;
      setbuf(stdin, NULL);
      cout<<"Digite o nome da turma da "<<serie<< "ª serie que deseja a lista dos alunos: ";
      getline(cin,nome_turma);
      setbuf(stdin, NULL);
      listar_alunos_turma_determinada(turmas,nome_turma,serie);
    }
    else if(menu == 6){
      cout<<"\nRelatório completo:\n";
      relatorio_completo(turmas);
    }
  }
}