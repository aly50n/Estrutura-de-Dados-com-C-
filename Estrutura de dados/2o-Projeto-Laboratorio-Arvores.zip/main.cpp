/*
criar uma lista encadeada de funcionários contendo nome e matrícula como dados. Considerando a possibilidade de que a lista contenha uma quantidade muito grande de elementos, a realização de pesquisas sequenciais pode ter desempenho abaixo do aceitável. Dessa forma, árvores binárias de pesquisa serão utilizadas como índices em operações de busca.
Devem ser criadas duas árvores de pesquisa: uma organizada por nome, outra por matrícula. As árvores não devem conter informações, e sim uma referência para a posição da lista que representam. O seguinte menu de opções deve ser oferecido ao usuário:


1 - Inserir elemento no fim da lista;
2 - Buscar elemento na lista por matrícula;
3 - Buscar elemento na lista por nome;
4 - Imprimir todos os elementos por ordem de matrícula;
5 - Imprimir todos os elementos por ordem de nome;
6 - Balancear árvores;
0 - Sair
*/

#include <iostream>

using namespace std;

struct noLista{
  string nome;
  int matricula;
  noLista *prox;
  noLista *ant;
};

struct descritor{
  noLista *ini;
  noLista *fim;
  int tam;
};

descritor* inicializar_descritor(){
  descritor *d = new descritor;
  d->ini = NULL;
  d->fim = NULL;
  d->tam = 0;
  return d;
}

struct noArvore{
  noLista* dados;
  noArvore *esq, *dir;
};

noArvore* inicializar_arvore(){
  return NULL;
}

void imprimir_pre(noArvore* raiz){
  if(raiz!=NULL){
    cout<<"Nome: "<<raiz->dados->nome<<", Matrícula: "<<raiz->dados->matricula<<"\n";
    imprimir_pre(raiz->esq);
    imprimir_pre(raiz->dir);
  }
}

void imprimir_central(noArvore* raiz){
  if(raiz!=NULL){
    imprimir_central(raiz->esq);
    cout<<"Nome: "<<raiz->dados->nome<<", Matrícula: "<<raiz->dados->matricula<<"\n";
    imprimir_central(raiz->dir);
  }
}

void imprimir_pos(noArvore* raiz){
  if(raiz!=NULL){
    imprimir_pos(raiz->esq);
    imprimir_pos(raiz->dir);
    cout<<"Nome: "<<raiz->dados->nome<<", Matrícula: "<<raiz->dados->matricula;
  }
}

void inserir_bst_nome(noArvore*&raiz,noLista* dado){
  if(raiz == NULL){
    raiz = new noArvore;
    raiz->dados = dado;
    raiz->esq = NULL;
    raiz->dir = NULL;
  }
  else if(dado->nome < raiz->dados->nome)
    inserir_bst_nome(raiz->esq, dado);
  else if(dado->nome > raiz->dados->nome)
    inserir_bst_nome(raiz->dir,dado);
  else{
    cout<<"Nome do funcionario já existe na árvore."<<endl;
  }
}

void inserir_bst_matricula(noArvore*&raiz,noLista* dado){
  if(raiz == NULL){
    raiz = new noArvore;
    raiz->dados = dado;
    raiz->esq = NULL;
    raiz->dir = NULL;
  }
  else if(dado->matricula < raiz->dados->matricula)
    inserir_bst_matricula(raiz->esq,dado);
  else if(dado->matricula > raiz->dados->matricula)
    inserir_bst_matricula(raiz->dir,dado);
  else{
    cout<<"Matricula já existe na árvore de dados."<<endl;
  }
}

noArvore* buscar_por_nome(noArvore* raiz,string nome){
  if(raiz == NULL || raiz->dados->nome == nome)
    return raiz;
  else if(nome < raiz->dados->nome)
    return buscar_por_nome(raiz->esq,nome);
  else
    return buscar_por_nome(raiz->dir,nome);
}

noArvore* buscar_por_matricula(noArvore* raiz,int matricula){
  if(raiz == NULL || raiz->dados->matricula == matricula)
    return raiz;
  else if(matricula < raiz->dados->matricula)
    return buscar_por_matricula(raiz->esq,matricula);
  else
    return buscar_por_matricula(raiz->dir,matricula);
}

int tamanho(noArvore* raiz){
  if(raiz == NULL)
    return 0;
  else
    return tamanho(raiz->esq) + tamanho(raiz->dir) + 1;
}

int altura(noArvore* raiz){
  if(raiz == NULL)
    return -1;
  else{
    int altE = altura(raiz->esq);
    int altD = altura(raiz->dir);
    if(altE > altD)
      return altE + 1;
    else
      return altD + 1;
  }
}

bool balanceada(noArvore *raiz){
  if(raiz == NULL)
    return true;
  else{
    if(abs(altura(raiz->esq) - altura(raiz->dir)) > 1)
      return false;
    else
      return balanceada(raiz->esq) && balanceada(raiz->dir) ; 
  }
}

void gerar_vetor(noArvore *raiz, noLista**vet, int &i){
  if(raiz != NULL){
    gerar_vetor(raiz->esq,vet,i);
    vet[i] = raiz->dados;
    i++;
    gerar_vetor(raiz->dir,vet,i);
  }
}

void destruir(noArvore *&raiz){
  if(raiz != NULL){
    destruir(raiz->esq);
    destruir(raiz->dir);
    delete raiz;
    raiz = NULL;
  }
}

void gerar_arvore(noArvore *&raiz, noLista* *vet, int ini, int fim){
  if(fim < ini)
    raiz = NULL;
  else{
    int meio = (ini+fim)/2;
    raiz = new noArvore;
    raiz->dados = vet[meio];
    gerar_arvore(raiz->esq, vet, ini, meio-1);
    gerar_arvore(raiz->dir, vet, meio+1, fim);
  }
}

void balanceamento_estatico(noArvore *&raiz){
  if(!balanceada(raiz)){
    int tam = tamanho(raiz);
    noLista* *vet = new noLista*[tam];
    int indice = 0;
    gerar_vetor(raiz, vet, indice);
    destruir(raiz);
    gerar_arvore(raiz, vet, 0, tam-1);
    delete [] vet;
  }
}

void ins_no_fim(descritor *d, string nome, int matricula){
  noLista* aux = new noLista;
  aux->ant= NULL;
  aux->prox= NULL;
  aux->nome = nome;
  aux->matricula = matricula;
  if(d->ini == NULL){
    d->ini = aux;
    d->fim = aux;
    d->tam++;
  }
  else{
    aux->ant= d->fim;
    d->fim->prox= aux;
    d->fim = aux;
    d->tam++;
  }
}

int main() {
  int menu = 1;
  noArvore *raiz_nome = inicializar_arvore();
  noArvore *raiz_mat = inicializar_arvore();
  descritor *descritor = inicializar_descritor();

  while(menu != 0){
    cout<<"\n================MENU=================\n";
    cout<<"1 - Inserir funcionario.\n2 - Buscar funcionario por matrícula.\n3 - Buscar funcionario por nome.\n4 - Imprimir todos funcionarios por ordem de matrícula.\n5 - Imprimir todos os funcionarios por ordem de nome.\n6 - Balancear árvores.\n0 - Sair.\n";
    cout<<"=======================================\n";
    cout<<"Escolha uma opção do menu: ";
    cin>>menu;
    cout<<"---------------------------------------\n";
    if(menu == 1){
      cout<<"==========1-INSERIR FUNCIONÁRIO==========\n";
      string nome;
      int matricula;
      setbuf(stdin, NULL);
      cout<<"Digite o nome do funcionario: ";
      getline(cin,nome);
      setbuf(stdin, NULL);
      cout<<"Digite a matrícula do funcionario: ";
      cin>>matricula;
      setbuf(stdin, NULL);
      ins_no_fim(descritor, nome, matricula);
      inserir_bst_matricula(raiz_mat, descritor->fim);
      inserir_bst_nome(raiz_nome, descritor->fim);
    }
    else if(menu == 2){
      cout<<"==========2-BUSCAR FUNCIONARIO POR MATRICULA==========\n";
      noArvore * raiz_aux;
      int matricula;
      cout<<"Digite a matrícula do funcionario que deseja encontrar: ";
      cin>>matricula;
      raiz_aux = buscar_por_matricula(raiz_mat, matricula);
      if(raiz_aux!=NULL){
        cout<<"\nMatricula encontrada!\n";
        cout<<"Nome: "<<raiz_aux->dados->nome<<", Matrícula: "<<raiz_aux->dados->matricula;
      }
      else{
        cout<<"A matricula buscada não foi encontrada!";
      }
    }
    else if(menu == 3){
      cout<<"==========3-BUSCAR FUNCIONARIO POR NOME==========\n";
      noArvore * raiz_aux;
      string nome;
      setbuf(stdin, NULL);
      cout<<"Digite o nome do funcionario que deseja encontrar: ";
      getline(cin,nome);
      setbuf(stdin, NULL);
      raiz_aux = buscar_por_nome(raiz_nome, nome);

       if(raiz_aux!=NULL){
        cout<<"\nO nome do funcionario foi encontrado!\n";
        cout<<"Nome: "<<raiz_aux->dados->nome<<", Matrícula: "<<raiz_aux->dados->matricula;
      }
      else{
        cout<<"O nome funcionario buscado não foi encontrado!";
      }
    }
    else if(menu == 4){
      cout<<"==========4-IMPRIMIR LISTA EM ORDEM POR MATRÍCULA==========\n";
      imprimir_central(raiz_mat);
    }
    else if(menu == 5){
      cout<<"==========5-IMPRIMIR LISTA EM ORDEM POR NOME==========\n";
      imprimir_central(raiz_nome);
    }
    else if(menu == 6){
      cout<<"==========6-BALANCEAR ÁRVORES==========\n";
      balanceamento_estatico(raiz_mat);
      balanceamento_estatico(raiz_nome);
      cout<<"As árvores de dados foram balanceadas!";
    }
  }
}