#include <iostream>
/*
=======================================================
1) Dado o tipo de dados de funcionário a seguir:
Matrícula - inteiro;
nome - string;
salário - double;
função - string;

3) Faça uma função que receba uma árvore binária de pesquisa contendo as mesmas informações da questão 1. A função deve retornar a soma dos salários de todos os vendedores (3,0 pontos).
=======================================================
*/
using namespace std;

struct noArvore{
  int matricula;
  string nome,funcao;
  double salario;
  noArvore *esq, *dir;
};

noArvore* inicializar(){
  return NULL;
}

void imprimir_central(noArvore* raiz){
  if(raiz!=NULL){
    imprimir_central(raiz->esq);
    cout<<"\nMatricula: "<<raiz->matricula<<"\nNome: "<<raiz->nome<<"\nFunção: "<<raiz->funcao<<"\nSalario: "<<raiz->salario<<"\n";
    imprimir_central(raiz->dir);
  }
}

void inserir_bst(noArvore*&raiz, int matricula,string nome, string funcao, double salario){
  if(raiz == NULL){
    raiz = new noArvore;
    raiz->matricula = matricula;
    raiz->nome = nome;
    raiz->funcao = funcao;
    raiz->salario = salario;
    raiz->esq = NULL;
    raiz->dir = NULL;
  }
  else if(matricula < raiz->matricula)
    inserir_bst(raiz->esq, matricula,nome,funcao,salario);
  else if(matricula > raiz->matricula)
    inserir_bst(raiz->dir,matricula,nome,funcao,salario);
  else{
    cout<<"Elemento já existe na árvore."<<endl;
  }
}

double somar_salario(noArvore *raiz){
  if(raiz == NULL)
    return 0;
  else
    return somar_salario(raiz->esq) + somar_salario(raiz->dir) + raiz->salario;
}


int main() {
  int menu = 1;
  noArvore *raiz = inicializar();
  while(menu != 0){
    cout<<"\n================MENU=================\n";
    cout<<"1 - Inserir funcionario.\n2 - imprimir funcionarios.\n3 - Imprimir a soma dos salarios dos funcionarios atuais.\n0 - Sair.\n";
    cout<<"=======================================\n";
    cout<<"Escolha uma opção do menu: ";
    cin>>menu;
    cout<<"---------------------------------------\n";
    if(menu == 1){
      int matricula;
      string nome, funcao;
      double salario;
      setbuf(stdin, NULL);
      cout<<"Digite a matricula: ";
      cin>>matricula;
      setbuf(stdin, NULL);
      cout<<"Digite o nome do funcionario: ";
      getline(cin,nome);
      setbuf(stdin, NULL);
      cout<<"Digite a funcao do funcionario: ";
      getline(cin,funcao);
      setbuf(stdin,NULL);
      cout<<"Digite o salario do funcionario: ";
      cin>>salario;
      setbuf(stdin, NULL);
      inserir_bst(raiz, matricula, nome, funcao, salario);
    }
    else if(menu == 2){
      imprimir_central(raiz);
    }
    else if(menu == 3){
      cout<<"\nA soma dos salarios atuais é igual a: "<<somar_salario(raiz);
    }
  }
}