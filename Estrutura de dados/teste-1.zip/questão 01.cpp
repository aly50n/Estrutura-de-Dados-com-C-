#include <iostream>
/*
=======================================================
1) Dado o tipo de dados de funcionário a seguir:
Matrícula - inteiro;
nome - string;
salário - double;
função - string;

Implemente uma tabela hash de tamanho M = 25. Os funcionários devem ser indexados pela sua matrícula e a função de hash deve ser h(x) = x % M. Para o tratamento de colisões, use listas simplesmente encadeadas.
Faça um programa com um laço para incluir funcionários na tabela, até que o usuário informe matrícula 0 (4,0 pontos)
=======================================================
*/
using namespace std;

struct noLista{
  int matricula;
  string nome;
  double salario;
  string funcao;
  noLista *prox;
};

noLista *inicializar()
{
  return NULL;
}

void inserir_fim(noLista* &l, int matricula, string nome, double salario, string funcao)
{
  noLista *novo = new noLista;
  novo->matricula = matricula;
  novo->nome = nome;
  novo->salario = salario;
  novo->funcao = funcao;
  novo->prox = NULL;
  if(l == NULL)
  {
    l = novo;
  }
  else
  {
    noLista *p = l;
    while(p->prox!=NULL)
    {
      p=p->prox;
    }
    p->prox = novo;
  }
}

void imprimir(noLista **hash, int m)
{
  for(int i=0;i<m;i++){
    noLista *l= hash[i];
    while(l!=NULL)
    {
      cout<<"\nMatricula: "<<l->matricula<<"\nNome: "<<l->nome<<"\nFunção: "<<l->funcao<<"\nSalario: "<<l->salario;
      l = l->prox;
      cout<<endl;
    }
  }
}



int main() {
  int menu = 1, M=25;
  noLista **hash = new noLista*[M];
  while(menu != 0){
    cout<<"\n================MENU=================\n";
    cout<<"1 - Inserir funcionario.\n2 - imprimir funcionarios.\n0 - Sair.\n";
    cout<<"=======================================\n";
    cout<<"Escolha uma opção do menu: ";
    cin>>menu;
    cout<<"---------------------------------------\n";
    if(menu == 1){
      int matricula;
      string nome, funcao;
      double salario;

      setbuf(stdin, NULL);
      cout<<"Digite a matricula(Digite 0 para parar de inserir): ";
      cin>>matricula;
      while(matricula != 0){
        setbuf(stdin, NULL);
        cout<<"Digite o nome do funcionario: ";
        getline(cin,nome);
        setbuf(stdin, NULL);
        cout<<"Digite a funcao do funcionario: ";
        getline(cin,funcao);
        setbuf(stdin,NULL);
        cout<<"Digite o salario do funcionario: ";
        cin>>salario;
        inserir_fim(hash[matricula % M], matricula, nome, salario, funcao);
        setbuf(stdin, NULL);
        cout<<"Digite a matricula: (Digite 0 para parar de inserir)";
        cin>>matricula;
      } 
    }
    else if(menu == 2){
      imprimir(hash, M);
    }
  }
}