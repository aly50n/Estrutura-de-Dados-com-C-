#include <iostream>

/*
=======================================================
2) Considere um grafo em que cada vértice representa uma pessoa e cada adjacência representa um voto. Faça uma função que receba a matriz de adjacência desse grafo e retorne o índice do vértice que venceu a eleição. Considere o índice de linha e coluna da matriz como os índices dos vértices (3,0 pontos).
=======================================================
*/
using namespace std;

#define TAM 5
int venceu_eleicao(int tam, int mat[TAM][TAM]){    
    for(int i =0; i< tam; i++){
        for(int j =0; j< tam; j++){
           cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }
    int candidatos[tam];
    for(int j =0; j< tam; j++){
           candidatos[j] = 0;
    }

    for(int i =0; i< tam; i++){
        for(int j =0; j< tam; j++){
            candidatos[j]+=mat[i][j];
        }
    }
   
    int maiorIndice = 0;    
    int maiorValor = 0;
    for(int i =0; i<tam; i++){
        if(candidatos[i]>maiorValor){
            maiorValor = candidatos[i];
            maiorIndice = i;
        }
    }    
    return maiorIndice;
}

int main() {
    int matrizADJ[TAM][TAM] = {
    {0, 1, 0, 0, 0},
    {0, 0, 0, 0, 1},
    {0, 0, 0, 0, 1},
    {0, 0, 0, 0, 1},
    {0, 0, 0, 1, 0}
    };
    int x = venceu_eleicao(TAM, matrizADJ);
    cout<<"\nQuem venceu foi o candidato do indice: "<<x;
}
