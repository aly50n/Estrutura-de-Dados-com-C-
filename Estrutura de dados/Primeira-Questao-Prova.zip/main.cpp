Time* maior_time(Time *t){
  jogador *j;
  Time *auxmaior = t;
  int cont = 0, maior = 0;
  while(t != NULL){
    cont = 0;
    j = t->elenco;
    while(j != NULL){
      cont++;
      j= j->prox;
    }
    if(maior < cont){
      maior = cont;
      auxmaior = t;
    }
    t = t->prox;
  }
  return auxmaior;
}