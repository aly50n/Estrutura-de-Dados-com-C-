#include <iostream>

using namespace std;

struct noArvore{
  int dado;
  noArvore *esq, *dir;
};

noArvore* inicializar(){
  return NULL;
}

void imprimir_pre(noArvore* raiz){
  if(raiz!=NULL){
    cout<<raiz->dado<<" ";
    imprimir_pre(raiz->esq);
    imprimir_pre(raiz->dir);
  }
}

void imprimir_central(noArvore* raiz){
  if(raiz!=NULL){
    imprimir_central(raiz->esq);
    cout<<raiz->dado<<" ";
    imprimir_central(raiz->dir);
  }
}

void imprimir_pos(noArvore* raiz){
  if(raiz!=NULL){
    imprimir_pos(raiz->esq);
    imprimir_pos(raiz->dir);
    cout<<raiz->dado<<" ";
  }
}

void inserir_bst(noArvore*&raiz, int info){
  if(raiz == NULL){
    raiz = new noArvore;
    raiz->dado = info;
    raiz->esq = NULL;
    raiz->dir = NULL;
  }
  else if(info < raiz->dado)
    inserir_bst(raiz->esq,info);
  else if(info > raiz->dado)
    inserir_bst(raiz->dir,info);
  else{
    cout<<"Elemento já existe na árvore."<<endl;
  }
}

noArvore* buscar_elemento(noArvore* raiz,int info){
  if(raiz == NULL || raiz->dado == info)
    return raiz;
  else if(info < raiz->dado)
    return buscar_elemento(raiz->esq,info);
  else
    return buscar_elemento(raiz->dir,info);
}

int tamanho(noArvore* raiz){
  if(raiz == NULL)
    return 0;
  else
    return tamanho(raiz->esq) + tamanho(raiz->dir) + 1;
}

int somar_elementos(noArvore* raiz){
  if(raiz == NULL)
    return 0;
  else
    return somar_elementos(raiz->esq) + somar_elementos(raiz->dir) + raiz->dado;
}

int altura(noArvore* raiz){
  if(raiz == NULL)
    return -1;
  else{
    int altE = altura(raiz->esq);
    int altD = altura(raiz->dir);
    if(altE > altD)
      return altE + 1;
    else
      return altD + 1;
  }
}

noArvore* maior(noArvore* raiz){
  if(raiz == NULL || raiz->dir == NULL)
    return raiz;
  else
    return maior(raiz->dir);
}

void remover(noArvore *&raiz, int elemento){
  if(raiz != NULL){
    if(elemento < raiz->dado)
      remover(raiz->esq,elemento);
    else if(elemento>raiz->dado)
      remover(raiz->dir,elemento);
    else{
      noArvore *auxRaiz;
      if(raiz->esq != NULL){
        noArvore *auxE;
        auxE = raiz->esq;
        auxRaiz = *&raiz;
        while(auxE->dir != NULL)
          auxE = auxE->dir;
        auxE->dir = raiz->dir;
        raiz = raiz->esq;
        delete auxRaiz;
      }
      else{
        auxRaiz = *&raiz;
        raiz = raiz->dir;
        delete auxRaiz;
      }
      
    }
  }
}

int main() {
  noArvore *arv1 = inicializar();
  int vet[6] = {20,12,18,4,8,10};
  for(int i = 0; i < 6; i++)
    inserir_bst(arv1, vet[i]);

  imprimir_central(arv1);
  cout<<endl;
 

  remover(arv1,12);
  imprimir_central(arv1);
  cout<<endl;
  remover(arv1,5);
  imprimir_central(arv1);
  cout<<endl;
  remover(arv1,9);
  imprimir_central(arv1);
  cout<<endl;
  remover(arv1,6);
  imprimir_central(arv1);
  cout<<endl;
  remover(arv1,7);
  imprimir_central(arv1);
  cout<<endl;
  remover(arv1,4);
  imprimir_central(arv1);
  cout<<endl;
}